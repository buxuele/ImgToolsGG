### Installation

> pip install ImgToolsGG

### Get started

How to multiply one number by another with this lib:

```
import os

print("ok")

```